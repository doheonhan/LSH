import pandas as pd

from datagen.mcutil.state_obj_ops import StateObject
from datagen.util import df2csvstring

from .aiutils.openai_utils import run_messages
from .aiutils.utils import StructuredExtractionTask
from .config.data_model import StateObjectOpSequence, VariableSpecs
from .config.load_config import (
    DATA_DESCRIPTION_PROMPT,
    OP_SEQUENCE_PROMPT,
    VARIABLE_EXRACTION_PROMPT,
    var_specs_to_text,
)


def generate_data_desc(data):
    data_desc_messages = [
        {"role": "system", "content": DATA_DESCRIPTION_PROMPT},
        {"role": "user", "content": df2csvstring(data)},
    ]
    return run_messages(data_desc_messages)


def generate_var_specs(data):
    var_extactor = StructuredExtractionTask(
        VARIABLE_EXRACTION_PROMPT, model=VariableSpecs
    )
    return var_extactor.extract(df2csvstring(data))


def single_oversampling_round(data, round_n, vrs=None, data_desc=None):
    csv_str = df2csvstring(data)

    if data_desc is None:
        data_desc = generate_data_desc(data)

    if vrs is None:
        vrs = generate_var_specs(data)

    var_desc_text = var_specs_to_text(vrs)
    final_extaction_prompt = OP_SEQUENCE_PROMPT.replace("|||n_out|||", str(round_n))
    final_extaction_prompt = final_extaction_prompt.replace(
        "|||data_example|||", csv_str
    )
    final_extaction_prompt += var_desc_text
    seq_extractor = StructuredExtractionTask(
        final_extaction_prompt, model=StateObjectOpSequence
    )
    seq = seq_extractor.extract(data_desc)

    state_obj = StateObject(vars=vrs)
    res = state_obj.execute_seq(seq)

    new_data = pd.DataFrame(res)
    return new_data


def oversample(
    data,
    new_samples,
    label_var,
    oversampled_label,
    sample_size=30,
    round_n=10,
    single_desc=False,
    single_vars=True,
):
    data_desc = None
    vrs = None

    if single_desc:
        data_desc = generate_data_desc(data)

    if single_vars:
        vrs = generate_var_specs(data)

    out_df = pd.DataFrame()
    while len(out_df) < new_samples:
        if sample_size > len(data):
            sample_size = len(data)
            print("Sample size is larger than data size, setting to", sample_size)
        sample = data.sample(sample_size)
        new_data = single_oversampling_round(
            sample, round_n, vrs=vrs, data_desc=data_desc
        )
        out_df = pd.concat([out_df, new_data])
        print("Generated", len(new_data), "samples", "total", len(out_df))
    if len(out_df) > new_samples:
        out_df = out_df.sample(new_samples)
    out_df.reset_index(drop=True, inplace=True)
    out_df[label_var] = oversampled_label
    return out_df
