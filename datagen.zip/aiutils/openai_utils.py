import logging

import json5
from openai import OpenAI

_LOGGER = logging.getLogger(__name__)
_API_KEY = "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" # Doheon
# _API_KEY = "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" # Grigorii
_MODEL = "gpt-4o-mini"
_CLIENT = OpenAI(api_key=_API_KEY)


def run_messages(messages, use_json=False, seed=None):
    _LOGGER.debug(f"Running messages: {messages}")
    chat_function = _CLIENT.chat.completions.create
    parsing = False
    if isinstance(use_json, bool):
        format = {"type": "json_object"} if use_json else None
    else:
        format = use_json
        chat_function = _CLIENT.beta.chat.completions.parse
        parsing = True
    response = chat_function(
        model=_MODEL,
        messages=messages,
        response_format=format,
        temperature=0.8,
        seed=seed,
        top_p=0.9,
    )
    choice = response.choices[0]
    assert choice.finish_reason == "stop", f"Finish reason: {choice.finish_reason}"

    msg = choice.message
    messages.append({"role": "assistant", "content": msg.content})
    if parsing:
        assert msg.parsed, f"Message not parsed: {msg}"
        return msg.parsed
    if use_json:
        obj = json5.loads(msg.content)
        return obj
    return msg.content
