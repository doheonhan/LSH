from typing import Generic, TypeVar

from pydantic import BaseModel

from .openai_utils import run_messages

T = TypeVar("T", bound="BaseModel")


class StructuredExtractionTask(Generic[T]):
    def __init__(self, prompt: str, model: T):
        self._prompt = prompt
        self._model = model

    def extract(self, text: str, seed=None) -> T:
        messages = [
            {"role": "system", "content": self._prompt},
            {"role": "user", "content": text},
        ]
        return run_messages(messages, use_json=self._model, seed=seed)


def chunk_list(input_list, chunk_size):
    if chunk_size <= 0:
        raise ValueError("Chunk size must be greater than zero")

    for i in range(0, len(input_list), chunk_size):
        yield input_list[i : i + chunk_size]
