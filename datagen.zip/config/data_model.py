from enum import Enum
from typing import List, Literal, Union

from pydantic import BaseModel, Field


class ChangeByOp(BaseModel):
    name: Literal["change_by"]
    var_name: str = Field(..., description="The name of the variable to change")
    value: float = Field(..., description="The size of the change in variable's units")


class SetToOp(BaseModel):
    name: Literal["set_to"]
    var_name: str = Field(..., description="The name of the variable to set")
    value: float = Field(..., description="The new value of the variable")


class OutputOp(BaseModel):
    name: Literal["output"]


class InitOp(BaseModel):
    name: Literal["init"]


class StateObjectOp(BaseModel):
    op: Union[ChangeByOp, SetToOp, OutputOp, InitOp] = Field(
        description="The operation to execute on the state object",
        # discriminator="name",
    )


class StateObjectOpSequence(BaseModel):
    op_seq: List[StateObjectOp] = Field(
        description="The sequence of operations to execute on the state object"
    )


class VariableUnits(str, Enum):
    boolean = "true or false"
    integer = "integer"
    anynum = "any number"


class VariableDistributionName(str, Enum):
    normal = "normal"
    uniform = "uniform"
    exponential = "exponential"
    tnormal = "truncated normal"
    none = "none"


class VariableDistribution(BaseModel):
    name: VariableDistributionName = Field(
        ..., description="The name of the distribution"
    )
    scale: float = Field(..., description="The scale of the distribution")
    vmin: float = Field(..., description="The minimum value of the variable")
    vmax: float = Field(..., description="The maximum value of the variable")


class VariableSpec(BaseModel):
    name: str = Field(..., description="The name of the variable")
    units: VariableUnits = Field(..., description="The units of the variable")
    dist: VariableDistribution = Field(
        ..., description="The distribution of the variable"
    )
    description: str = Field(..., description="A description of the variable")


class VariableSpecs(BaseModel):
    variables: List[VariableSpec] = Field(
        description="The list of variables in the dataset"
    )
