import copy
import logging

from ..config.data_model import VariableSpecs
from .dists import MC_FN_MAP

_logger = logging.getLogger(__name__)


class StateObject(object):
    def __init__(
        self,
        vars: VariableSpecs,
    ):
        self.state = {}
        self._OP_FN_MAP = {
            "init": self._init_op,
            "output": self._output_op,
            "change_by": self._change_by_op,
            "set_to": self._set_to_op,
        }
        self._vars = vars
        self._var_dict = {v.name: v for v in vars.variables}

    def _init_op(self, args, out):
        _logger.debug("Initializing state object")
        self.state = {}
        for v in self._vars.variables:
            if v.units == "true or false":
                self.state[v.name] = False
            else:
                self.state[v.name] = 0
        return out

    def _change_by_op(self, args, out):
        _logger.debug(f"Changing state object by {args.value} for {args.var_name}")
        self.state[args.var_name] += args.value
        return copy.copy(out)

    def _set_to_op(self, args, out):
        _logger.debug(f"Setting state object to {args.value} for {args.var_name}")
        self.state[args.var_name] = args.value
        return copy.copy(out)

    def _output_op(self, args, out):
        _logger.debug("Outputting state object")
        out_dct = copy.copy(self.state)

        for var in out_dct:
            var_desc = self._var_dict[var]
            dist_fn = MC_FN_MAP[var_desc.dist.name.value]
            dist_params = var_desc.dist
            out_dct[var] = dist_fn(out_dct[var], dist_params)

        out.append(copy.copy(out_dct))

        return copy.copy(out)

    def execute_seq(self, seq):
        _logger.debug("Executing sequence of state object operations")
        out = []
        for s in seq.op_seq:
            s = s.op
            op_fn = self._OP_FN_MAP[s.name]
            out = op_fn(s, out)
        return out
