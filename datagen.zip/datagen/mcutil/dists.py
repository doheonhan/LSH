import numpy as np
import scipy.stats as stats


def exp_dist_mc(prev, dparams):
    return prev + np.random.exponential(dparams.scale)


def normal_dist_mc(prev, dparams):
    r = np.random.normal(loc=prev, scale=dparams.scale)
    return r


def tnormal_dict_mc(prev, dparams):
    dobj = stats.truncnorm(
        (dparams.vmin - prev) / dparams.scale,
        (dparams.vmax - prev) / dparams.scale,
        loc=prev,
        scale=dparams.scale,
    )
    r = float(dobj.rvs(1).squeeze())
    return r


def none_dist_mc(prev, dparams):
    return prev


def uniform_dist_mc(prev, dparams):
    return np.random.uniform(dparams.vmin, dparams.vmax)


MC_FN_MAP = {
    "exponential": exp_dist_mc,
    "normal": normal_dist_mc,
    "truncated normal": tnormal_dict_mc,
    "uniform": uniform_dist_mc,
    "none": none_dist_mc,
}
