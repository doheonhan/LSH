import logging

import json5
from openai import OpenAI

_LOGGER = logging.getLogger(__name__)
_API_KEY = Your Own API



### USE For GPT-4o-mini ###
_MODEL = "gpt-4o-mini"
_CLIENT = OpenAI(api_key=_API_KEY)
### USE For GPT-4o-mini ###



### USE For Devstral 2 ###
_MODEL = "gpt-4o-mini"
_CLIENT = OpenAI(
    base_url="https://openrouter.ai/api/v1",
    api_key=_API_KEY,
)### USE For Devstral 2 ###



def run_messages(messages, use_json=False, seed=None):
    _LOGGER.debug(f"Running messages: {messages}")
    chat_function = _CLIENT.chat.completions.create
    parsing = False
    if isinstance(use_json, bool):
        format = {"type": "json_object"} if use_json else None
    else:
        format = use_json
        chat_function = _CLIENT.beta.chat.completions.parse
        parsing = True
    response = chat_function(
        model=_MODEL,
        messages=messages,
        response_format=format,
        temperature=0.8,
        seed=seed,
        top_p=0.9,
    )
    choice = response.choices[0]
    assert choice.finish_reason == "stop", f"Finish reason: {choice.finish_reason}"

    msg = choice.message
    messages.append({"role": "assistant", "content": msg.content})
    if parsing:
        assert msg.parsed, f"Message not parsed: {msg}"
        return msg.parsed
    if use_json:
        obj = json5.loads(msg.content)
        return obj
    return msg.content
