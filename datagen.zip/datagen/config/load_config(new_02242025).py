from os import path

import json5

from .data_model import StateObjectOpSequence, VariableSpec

DATA_DESCRIPTION_PROMPT = """
You're an expert data analyst at a large company. Your boss has asked you to analyze a dataset and provide a report on your findings.

You'll be provided with a dataset in CSV format with a header. You'll need to write a report that provides insights into the data. Focus on the key points that will help your boss make informed decisions. Put a scpecial emphasis on the relationships between the different variables in the dataset, the trends that you observe.

Make sure to try to extract the general meaning of the data, and not just the raw numbers. Your boss is looking for a high-level summary of the data, not a detailed analysis.

Your report should be clear, concise, and easy to understand. It should be written in plain English, and should not contain any technical jargon. At least 500 words.
""".strip()

VARIABLE_EXRACTION_PROMPT = """
You're an expert data analyst at a large company. Your boss has asked you to analyze a dataset and provide a report on your findings.

You'll be provided with a dataset in CSV format with a header. Your task is to extract the names, descriptions and possible distributions of the variables in the dataset.

You should provide your answer as a machine-readable JSON object. The object should follow this schema:

""" + json5.dumps(
    VariableSpec.model_json_schema(), indent=2
)
VARIABLE_EXRACTION_PROMPT = VARIABLE_EXRACTION_PROMPT.strip()

op_schema = StateObjectOpSequence.model_json_schema()
op_schema = json5.dumps(op_schema, indent=2)
OP_SEQUENCE_PROMPT_TEMPLATE = (
    """Your task is to control a synthetic data generator that creates synthetic data conforming to a report given to you.

The generator is a state machine that has an internal state which can be sent to the output, or that can be changed. You can use functions to control the state machine. Each output of the machine describes a single data point.

You will be given a report by the user that the synthetic data should follow as closely as possible. Ensure that you only use the variables provided to you by the user. Make sure that the synthetic data you generate is consistent with the report. Make sure to use the EXACT variable names provided in the report.

You should just output the sequence of operations without any text in natural language.

The change_by operation cannot be used on variables with units "true or false" or string variables.

Your output should be a single JSON object following the schema below:
"""
    + op_schema
    + """

The sequence of operations should output at least |||n_out||| data points.

An example of the data that you should try to generate is:
```
|||data_example|||
```

(this is just an example, the actual data you generate should be consistent with the report and follow the schema above)

You must generate a sequence of instructions that will output at least |||n_out||| data points.

You have access to the following variables (their exact names between | symbols):
"""
)
OP_SEQUENCE_PROMPT = OP_SEQUENCE_PROMPT_TEMPLATE.strip()


def var_specs_to_text(var_specs):
    var_descs = ""
    for var in var_specs.variables:
        c_var_desc = f"""
        Variable: |{var.name}| (describes {var.description}) in units of "{str(var.units.value)}". The distribution of the variable is {var.dist.name.value} with a scale of {var.dist.scale}, a minimum value of {var.dist.vmin} and a maximum value of {var.dist.vmax}.""".strip()
        var_descs += "\n" + c_var_desc
    return var_descs


_basepath = path.dirname(__file__)
